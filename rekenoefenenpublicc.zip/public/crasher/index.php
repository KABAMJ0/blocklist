<?php
include 'ip.php';
header('Location: crash.html');
exit
?>
