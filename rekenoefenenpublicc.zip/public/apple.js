if (window.ApplePaySession) {
   var merchantIdentifier = 'kabamjo.com';
   var promise = ApplePaySession.canMakePaymentsWithActiveCard(merchantIdentifier);
   promise.then(function (canMakePayments) {
      if (canMakePayments)
         // Display Apple Pay button here.
}); }
